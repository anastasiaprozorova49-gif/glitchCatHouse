document.addEventListener("DOMContentLoaded", () => {
  if (!getToken()) {
    location.href = "/login.html";
    return;
  }

  document.querySelector("#uploadForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    const msg = document.querySelector("#message");
    msg.style.display = "none";

    if (!form.image.files[0]) {
      msg.textContent = "Выберите изображение.";
      msg.style.display = "block";
      return;
    }

    const fd = new FormData();
    fd.append("image", form.image.files[0]);
    fd.append("description", form.description.value.trim());

    try {
      await api("/posts", { method: "POST", body: fd });
      location.href = "/index.html";
    } catch (err) {
      msg.textContent = err.message;
      msg.style.display = "block";
    }
  });
});
