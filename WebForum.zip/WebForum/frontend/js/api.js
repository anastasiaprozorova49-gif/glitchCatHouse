const API = "/api";

function getToken() {
  return localStorage.getItem("glitch_token");
}

function setAuth(data) {
  localStorage.setItem("glitch_token", data.token);
  localStorage.setItem("glitch_user", JSON.stringify(data.user));
}

function logout() {
  localStorage.removeItem("glitch_token");
  localStorage.removeItem("glitch_user");
  window.location.href = "/index.html";
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  const token = getToken();

  if (token) headers.Authorization = `Bearer ${token}`;

  const isFormData = options.body instanceof FormData;
  if (!isFormData && options.body && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }

  const response = await fetch(API + path, { ...options, headers });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(data.message || "Ошибка запроса");
    error.status = response.status;
    throw error;
  }

  return data;
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function avatarUrl(path) {
  return path || "/assets/logo.png";
}
