document.addEventListener("DOMContentLoaded", async () => {
  setupNav();
  await loadFeed();
});

function setupNav() {
  const auth = document.querySelector("#authArea");
  if (!auth) return;

  const user = JSON.parse(localStorage.getItem("glitch_user") || "null");

  if (user) {
    auth.innerHTML = `
      <a href="/profile.html?id=${user.ID}">Профиль</a>
      <a href="/upload.html">+ Работа</a>
      <button class="nav-button" id="logoutBtn">Выйти</button>
    `;
    document.querySelector("#logoutBtn").onclick = logout;
  } else {
    auth.innerHTML = `
      <a href="/login.html">Войти</a>
      <a href="/register.html">Регистрация</a>
    `;
  }
}

async function loadFeed() {
  const feed = document.querySelector("#feed");
  try {
    const { posts } = await api("/posts");

    if (!posts.length) {
      feed.innerHTML = `<div class="empty">Пока нет работ. Стань первым, кто загрузит glitch-art.</div>`;
      return;
    }

    feed.innerHTML = posts.map(postCard).join("");

    document.querySelectorAll(".like-button").forEach(btn => {
      btn.addEventListener("click", async () => {
        if (!getToken()) {
          window.location.href = "/login.html";
          return;
        }

        try {
          const result = await api(`/posts/${btn.dataset.id}/like`, { method: "POST" });
          btn.querySelector(".like-count").textContent = result.likes;
        } catch (err) {
          alert(err.message);
        }
      });
    });

    document.querySelectorAll("[data-view-id]").forEach(el => {
      api(`/posts/${el.dataset.viewId}/view`, { method: "POST" }).catch(() => {});
    });
  } catch (err) {
    feed.innerHTML = `<div class="empty">${escapeHtml(err.message)}</div>`;
  }
}

function postCard(post) {
  return `
    <article class="card">
      <a href="/profile.html?id=${post.UserID}">
        <img class="card-image" src="${escapeHtml(post.ImagePath)}"
             alt="Работа @${escapeHtml(post.Nickname)}"
             data-view-id="${post.ID}">
      </a>
      <div class="card-body">
        <div class="author">
          <img class="avatar" src="${escapeHtml(avatarUrl(post.Avatar))}" alt="">
          <a href="/profile.html?id=${post.UserID}">@${escapeHtml(post.Nickname)}</a>
        </div>
        <div>${escapeHtml(post.Description || "")}</div>
        <div class="stats">
          <button class="like-button" data-id="${post.ID}">
            ♥ <span class="like-count">${post.Likes}</span>
          </button>
          <span>◉ ${post.Views}</span>
        </div>
      </div>
    </article>
  `;
}
