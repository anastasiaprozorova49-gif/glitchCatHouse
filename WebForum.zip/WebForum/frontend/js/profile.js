document.addEventListener("DOMContentLoaded", async () => {
  const current = JSON.parse(localStorage.getItem("glitch_user") || "null");
  const params = new URLSearchParams(location.search);
  const id = params.get("id") || (current && current.ID);

  if (!id) {
    location.href = "/login.html";
    return;
  }

  try {
    const { user, posts } = await api(`/users/${id}`);
    renderProfile(user, posts, current && Number(current.ID) === Number(user.ID));
  } catch (err) {
    document.querySelector("#profile").innerHTML =
      `<div class="empty">${escapeHtml(err.message)}</div>`;
  }
});

function renderProfile(user, posts, isOwner) {
  const profile = document.querySelector("#profile");

  profile.innerHTML = `
    <section class="profile-head">
      <img class="profile-avatar" src="${escapeHtml(avatarUrl(user.Avatar))}" alt="Avatar">
      <div>
        <div class="profile-name">@${escapeHtml(user.Nickname)}</div>
        <div class="profile-stats">
          <span><b>${user.Count_Work}</b> works</span>
          <span><b>${posts.reduce((sum, p) => sum + Number(p.Likes), 0)}</b> likes</span>
        </div>
        <p>${escapeHtml(user.Description || "No signal...")}</p>
        ${isOwner ? `<button class="nav-button" id="editProfile">EDIT PROFILE</button>` : ""}
      </div>
    </section>

    <h2 class="section-title">WORKS</h2>
    <div class="feed">
      ${posts.length ? posts.map(p => `
        <article class="card">
          <img class="card-image" src="${escapeHtml(p.ImagePath)}" alt="">
          <div class="card-body">
            <div>${escapeHtml(p.Description || "")}</div>
            <div class="stats">♥ ${p.Likes} &nbsp; ◉ ${p.Views}</div>
            ${isOwner ? `<button class="nav-button delete-post" data-id="${p.ID}">DELETE</button>` : ""}
          </div>
        </article>
      `).join("") : `<div class="empty">Работ пока нет.</div>`}
    </div>
  `;

  if (isOwner) {
    document.querySelector("#editProfile").onclick = () => openEditor(user);
    document.querySelectorAll(".delete-post").forEach(btn => {
      btn.onclick = async () => {
        if (!confirm("Удалить эту работу?")) return;
        try {
          await api(`/posts/${btn.dataset.id}`, { method: "DELETE" });
          location.reload();
        } catch (err) {
          alert(err.message);
        }
      };
    });
  }
}

function openEditor(user) {
  const modal = document.querySelector("#modal");
  modal.innerHTML = `
    <div class="form-card">
      <h1>EDIT PROFILE</h1>
      <form id="editForm">
        <div class="field">
          <label>Nickname</label>
          <input name="nickname" value="${escapeHtml(user.Nickname)}" required maxlength="30">
        </div>
        <div class="field">
          <label>Description</label>
          <textarea name="description" maxlength="500">${escapeHtml(user.Description || "")}</textarea>
        </div>
        <div class="field">
          <label>Avatar</label>
          <input name="avatar" type="file" accept="image/*">
        </div>
        <div id="editMessage" class="error"></div>
        <button class="btn">SAVE</button>
      </form>
    </div>
  `;
  modal.style.display = "grid";

  document.querySelector("#editForm").onsubmit = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const msg = document.querySelector("#editMessage");

    try {
      const data = await api("/users/me", {
        method: "PUT",
        body: JSON.stringify({
          nickname: form.nickname.value.trim(),
          description: form.description.value.trim()
        })
      });

      if (form.avatar.files[0]) {
        const fd = new FormData();
        fd.append("avatar", form.avatar.files[0]);
        await api("/users/me/avatar", { method: "POST", body: fd });
      }

      localStorage.setItem("glitch_user", JSON.stringify(data.user));
      location.reload();
    } catch (err) {
      msg.textContent = err.message;
      msg.style.display = "block";
    }
  };
}
