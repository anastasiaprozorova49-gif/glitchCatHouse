document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("#authForm");
  if (!form) return;

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.querySelector("#message");
    message.style.display = "none";

    const nickname = form.nickname.value.trim();
    const password = form.password.value;

    try {
      const endpoint = form.dataset.mode === "register"
        ? "/auth/register"
        : "/auth/login";

      const data = await api(endpoint, {
        method: "POST",
        body: JSON.stringify({ nickname, password })
      });

      setAuth(data);
      window.location.href = "/index.html";
    } catch (err) {
      message.textContent = err.message;
      message.className = "error";
      message.style.display = "block";
    }
  });
});
