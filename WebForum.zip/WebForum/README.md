# WebForum

Запуск:

```powershell
npm.cmd install
npm.cmd start
```

Откройте http://localhost:3000

Используется SQLite через sql.js. Отдельно устанавливать SQL Server, SSMS, SQLite, Python или Build Tools не требуется.

Подробное объяснение кода: `Документация_по_файлам_WebForum.md`
