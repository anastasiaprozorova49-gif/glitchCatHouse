const express=require('express');const cors=require('cors');const path=require('path');const fs=require('fs');require('dotenv').config();
const db=require('./db');const authRoutes=require('./routes/auth');const userRoutes=require('./routes/users');const postRoutes=require('./routes/posts');
const app=express(),PORT=Number(process.env.PORT||3000);const uploadDir=path.join(__dirname,'uploads');fs.mkdirSync(uploadDir,{recursive:true});
app.use(cors());app.use(express.json());app.use(express.urlencoded({extended:true}));app.use('/uploads',express.static(uploadDir));app.use('/api/auth',authRoutes);app.use('/api/users',userRoutes);app.use('/api/posts',postRoutes);app.use(express.static(path.join(__dirname,'..','frontend')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','frontend','index.html')));
db.initDb().then(()=>app.listen(PORT,()=>console.log(`WebForum: http://localhost:${PORT}`))).catch(e=>{console.error(e);process.exit(1);});
