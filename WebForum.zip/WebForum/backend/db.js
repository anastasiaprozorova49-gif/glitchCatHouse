const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const dataDir = path.join(__dirname, '..', 'database');
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = process.env.DB_PATH ? path.resolve(process.env.DB_PATH) : path.join(dataDir, 'webforum.db');
let db;

function save(){ fs.writeFileSync(dbPath, Buffer.from(db.export())); }
async function initDb(){
  const SQL=await initSqlJs();
  db=fs.existsSync(dbPath)?new SQL.Database(fs.readFileSync(dbPath)):new SQL.Database();
  db.run('PRAGMA foreign_keys = ON;');
  db.run(`CREATE TABLE IF NOT EXISTS Users (ID INTEGER PRIMARY KEY AUTOINCREMENT, Nickname TEXT NOT NULL UNIQUE COLLATE NOCASE, PasswordHash TEXT NOT NULL, Count_Work INTEGER NOT NULL DEFAULT 0, Avatar TEXT, Description TEXT, CreatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS Posts (ID INTEGER PRIMARY KEY AUTOINCREMENT, UserID INTEGER NOT NULL, ImagePath TEXT NOT NULL, Description TEXT, Views INTEGER NOT NULL DEFAULT 0, CreatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(UserID) REFERENCES Users(ID) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS Likes (ID INTEGER PRIMARY KEY AUTOINCREMENT, PostID INTEGER NOT NULL, UserID INTEGER NOT NULL, CreatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(PostID,UserID), FOREIGN KEY(PostID) REFERENCES Posts(ID) ON DELETE CASCADE, FOREIGN KEY(UserID) REFERENCES Users(ID) ON DELETE CASCADE);`);
  save();
}
function all(sql,params=[]){const s=db.prepare(sql);s.bind(params);const r=[];while(s.step())r.push(s.getAsObject());s.free();return r;}
function get(sql,params=[]){return all(sql,params)[0];}
function run(sql,params=[]){db.run(sql,params);const changes=db.getRowsModified();save();return {changes};}
module.exports={initDb,all,get,run,save};
